#!/usr/bin/perl 
use warnings;
use strict;
# 
# By Nick Niu on 2020/2/29.
#

## HDD attached to SATA

my $i='$10';
my @hdds=`ls -l /dev/sd* | awk -F ' ' {' print $i '} | grep -vE "[0-9]"`;
#print @hdds; 
my $x = 0;

my $hdd;
if (@hdds) {
    foreach (@hdds) {
    	chomp;
    	my $pot= `smartctl -a $_ | grep -i power_on_hours | awk -F ' ' {'print $i'}`;
    	if ($pot){
    	    $x++;
	    print "HDD SATA attached power_on_hours:\n" if $x == 1;
	    print "    $_: $pot" if $pot;
        }
}
}
print "No SATA atached HDD found!\n" if $x == 0;
print "\n";


## HDD attached to RAID
my $y='$2';
my $raidq = `/opt/MegaRAID/storcli/storcli64 show | grep "Number of Controllers" | awk -F "=" {'print $y'}`;
chomp $raidq;
$raidq = int($raidq);

if ($raidq){
print "$raidq RAID card found:\n";
    my @rHdds= `/opt/MegaRAID/storcli/storcli64 /call/eall/sall show | grep -E "[0-9]:[0-9]" | awk -F " " {'print $y'}`;
    my $dev;
    for $dev (@hdds) { 
	chomp $dev;
    for $hdd (@rHdds){
        chomp $hdd;
	my $pot = `smartctl -a -d sat+megaraid,$hdd $dev | grep -i "Power_On_Hours" | awk -F " " {'print $i'} `;
        last if not $pot;
	print "    $dev: $pot" if $pot;
    }
    }
}
